import SocketServer
import struct
import random

HOST, PORT = "localhost", 55555

def _hex(data):
    bdata = bytearray(data)
    hc = '0123456789ABCDEF'
    return ' '.join(['%s%s' %(hc[(d >> 4) & 0x0F], hc[d & 0x0F]) for d in bdata])

def _get_value(fmt, data):
    return struct.unpack(fmt, ''.join([chr(x) for x in data]))[0]

def _printable(data):
    not_printable = ''.join(chr(i) for i in xrange(0,32)) + chr(127)
    ns = []
    for i in xrange(0, len(data)):
        c = chr(data[i])
        if c in not_printable:
            ns.append('.')
        else:
            ns.append(c)
    return ''.join(ns)

def _hex_text(data, n, line_head):
    bdata = bytearray(data)
    r = len(data) % n
    last = len(data) / n + (r and 1 or 0)
    m = ''
    for i in xrange(0, last):
        k = i == last-1 and r or n
        m += line_head + _hex(bdata[i*n : i*n+k]) + ((last > 1 and r) and '   '*(n-k) or '') + ' | '
        m += _printable(bdata[i*n :  i*n+k]) + (i < last - 1 and '\n' or '')
    return m

class MyTCPHandler(SocketServer.BaseRequestHandler):
    error_probability = 0

    def _read_swap(self, n):
        x = bytearray(self.request.recv(n))
        x.reverse()
        return x

    def _parse(self):
        s = self.request
        self._swap = False
        exit = False

        try:
            msg = s.recv(1)
            generate_error = (random.uniform(0, 1) < self.error_probability)

            if msg == 'A' or msg == 'B' or msg == 'E':
                msg = _hex_text(msg, 20, '  ')
                reply = b'Z'
            elif msg == 'X':
                msg = _hex_text(msg, 20, '  ')
                reply = b'Z'
                exit = True
            elif msg == 'D':
                m = _get_value(">h", self._read_swap(2))
                d = bytearray(s.recv(m))
                msg = '  ' + msg + " %d\n" %m + _hex_text(d, 20, '  ')
                reply = b'Z'
            elif msg == 'N':
                msg = '  ' + msg + " %d.%d" %(_get_value(">I", self._read_swap(4)), _get_value(">I", self._read_swap(4)))
                reply = b'Z'
            elif msg == 'Q':
                msg += s.recv(4)
                if msg == 'QNTEL':
                    self._swap = True
                    print 'Intel byte order'
                msg = _hex_text(msg, 20, '  ')
                reply = b'I\x01'
            elif msg == 'T':
                msg = '  ' + msg + " %d" %_get_value(">I", self._read_swap(4))
                reply = b'Z'
            else:
                msg = _hex_text(msg, 20, '  ')
                reply = b'F\x00\x01'
                self.error_pkt += 1

            print 'Packet ID %d, Errors %d' %(self.pkt_count, self.error_pkt)
            print 'Msg:\n'+ msg
            print 'Reply:\n' + _hex_text(reply, 20, '  ')

            if generate_error and reply[0] != ord('F'):
                print 'Generating a false error (discard previous reply)'
                reply = b'F\x00\x02'
                self.error_pkt += 1

            self.pkt_count += 1
            self.request.sendall(reply)

        except Exception, e:
            print e
            raise e

        return not exit

    def handle(self):
        # self.request is the TCP socket connected to the client
        self.error_pkt = 0
        self.pkt_count = 0
        print '+-------------------+'
        print '| Connection OPENED |'
        print '+-------------------+'
        print 'Generating error packets with probability %f' %self.error_probability
        while self._parse(): pass
        print '+-------------------+'
        print '| Connection CLOSED |'
        print '+-------------------+'

if __name__ == "__main__":
    MyTCPHandler.error_probability = 0.05 # set this to a value in [0,1] if you want to generate a random error
    server = SocketServer.TCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()
