As several people asked, I prepared a couple of elementary scripts that show how one can give feedback in PsyScope X -- something that should be elementary, but unfortunately is not in PsyScope X.

The scripts show how one can save and successively present a string typed by a subject, or a single keypress, whether numeric or alphanumeric.

They also exemplify some new features of PsyScope X concerning how to refer to single keypresses or the contents of Key Sequence events, that is, expressions such as:

{key->strippedsequence}
{key->sequence}

and
key->keys.1

The script Numeric feedback Script will present the number of times you pressed a key within a certain time.
The script Text Feedback Script will repeat the string you typed as an entry of a KeyPress event. 

Both scripts give feedback between trials. The script Within Trial Feedback Script shows how feedback can also be presented within the same trial. 

